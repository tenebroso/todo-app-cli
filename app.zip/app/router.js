var Router = Ember.Router.extend({
  location: ENV.locationType
});

Router.map(function() {
	this.resource('todos', { path: '/' }, function() {
  	this.route('active');
  	this.route('completed');
  });
});

Ember.TodosRoute = Ember.Route.extend({
  model: function() {
    return this.store.find('todo');
  }
});

Ember.TodosIndexRoute = Ember.Route.extend({
  model: function() {
    return this.modelFor('todos');
  }
});

Ember.TodosActiveRoute = Ember.Route.extend({
  model: function(){
    return this.store.filter('todo', function(todo) {
      return !todo.get('isCompleted');
    });
  },
  renderTemplate: function(controller) {
    this.render('todos/index', {controller: controller});
  }
});

Ember.TodosCompletedRoute = Ember.Route.extend({
  model: function() {
    return this.store.filter('todo', function(todo) {
      return todo.get('isCompleted');
    });
  },
  renderTemplate: function(controller) {
    this.render('todos/index', {controller: controller});
  }
});

export default Router;
